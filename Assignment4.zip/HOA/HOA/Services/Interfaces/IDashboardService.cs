﻿using HOA.Models;

namespace HOA.Services.Interfaces
{
    public interface IDashboardService
    {
        Dashboard GetDashboardData();

    }
}
