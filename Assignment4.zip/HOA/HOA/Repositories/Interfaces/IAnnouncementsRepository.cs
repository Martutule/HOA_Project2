﻿using HOA.Models;

namespace HOA.Repositories.Interfaces
{
    public interface IAnnouncementsRepository: IRepositoryBase<Announcement>
    {
    }
}
