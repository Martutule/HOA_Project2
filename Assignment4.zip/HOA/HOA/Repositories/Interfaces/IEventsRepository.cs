﻿using HOA.Models;

namespace HOA.Repositories.Interfaces
{
    public interface IEventsRepository: IRepositoryBase<Event>
    {
    }
}
