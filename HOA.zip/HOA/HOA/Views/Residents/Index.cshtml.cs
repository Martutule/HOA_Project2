using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HOA.Views.Home
{
    public class ResidentsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
