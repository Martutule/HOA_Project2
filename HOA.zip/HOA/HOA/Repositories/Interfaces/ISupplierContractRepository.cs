using HOA.Models;

namespace HOA.Repositories.Interfaces {

    public interface ISupplierContractRepository : IRepositoryBase<SupplierContract>
    {
    }
}