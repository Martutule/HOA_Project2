﻿using HOA.Models;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;

namespace HOA.Repositories.Interfaces
{
    public interface INotificationRepository : IRepositoryBase<Notification>
    {
    }
}
