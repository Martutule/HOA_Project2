﻿namespace HOA.Repositories.Interfaces
{
    public interface IRepository<T>
    {
    }
}