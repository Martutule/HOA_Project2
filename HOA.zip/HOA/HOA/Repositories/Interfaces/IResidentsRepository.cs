﻿using HOA.Models;

namespace HOA.Repositories.Interfaces
{
    public interface IResidentsRepository : IRepositoryBase<Resident>
    {
    }
}
